// 监听点击事件，控制 Profile 下拉菜单
document.getElementById("profile-btn").addEventListener("click", function() {
    document.getElementById("dropdown-menu").classList.toggle("hidden");
});

// 点击页面其他地方时隐藏下拉菜单
document.addEventListener("click", function(event) {
    let profileDropdown = document.getElementById("profile-btn");
    let dropdownMenu = document.getElementById("dropdown-menu");

    if (!profileDropdown.contains(event.target) && !dropdownMenu.contains(event.target)) {
        dropdownMenu.classList.add("hidden");
    }
});

// 处理 Logout 功能
function handleLogout() {
    localStorage.removeItem("username"); // 清除本地存储的用户名
    alert("Logged out successfully!");
    window.location.href = "login.html"; // 跳转到登录页面
}

// 绑定 Logout 按钮
document.getElementById("dropdown-logout").addEventListener("click", handleLogout);
document.getElementById("sidebar-logout").addEventListener("click", handleLogout);
